"""EduMind: one Flask server for everything.

Usage:  python start.py        (Windows: py start.py)

One server on http://localhost:8000 that
  * serves the EduMind website
  * runs the Edge TTS voices   (/api/tts, /api/voices)
  * proxies OmniRoute requests (/api/chat) and can start OmniRoute for you
Settings live in the .env file. Press Ctrl+C to stop everything.
"""
import os, sys, subprocess
IS_TERMUX = "com.termux" in os.environ.get("PREFIX", "")
os.environ.setdefault("FLASK_SKIP_DOTENV", "1")

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
ENV_PATH = os.path.join(HERE, ".env")

DEFAULT_ENV = """# EduMind settings. Edit, save, then restart start.py.

# Your OmniRoute OpenAI-compatible endpoint (the model is always "auto").
# API keys are NOT stored here: every user enters their own key in the browser.
OMNIROUTE_BASE_URL=http://localhost:20128/v1

# Start OmniRoute automatically (runs the `omniroute` command if it is installed
# and nothing is listening yet). Ignored when the URL is not on this computer.
OMNIROUTE_AUTOSTART=true

# Also publish OmniRoute's /v1 API on this same port, so ONE tunnel (e.g. ngrok on this
# port) shares both EduMind and OmniRoute. Others can then use  https://YOUR-TUNNEL/v1
# as an OpenAI-compatible base URL. OmniRoute still checks its own API keys.
# (The OmniRoute dashboard is never shared.) Set to false to turn this off.
EXPOSE_OMNIROUTE_API=true

# Where EduMind listens
HOST=127.0.0.1
PORT=8000
"""
if IS_TERMUX:   # a phone should not run OmniRoute (Node.js) next to this unless you ask for it
    DEFAULT_ENV = DEFAULT_ENV.replace("OMNIROUTE_AUTOSTART=true", "OMNIROUTE_AUTOSTART=false")
DEFAULTS = {"OMNIROUTE_BASE_URL": "http://localhost:20128/v1", "OMNIROUTE_AUTOSTART": "false" if IS_TERMUX else "true", "EXPOSE_OMNIROUTE_API": "true", "HOST": "127.0.0.1", "PORT": "8000"}

def load_env():
    env = dict(DEFAULTS)
    try:
        with open(ENV_PATH, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                v = v.strip()
                if " #" in v and v[:1] not in "'\"":
                    v = v.split(" #", 1)[0].strip()      # PORT=8000  # comment
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
                    v = v[1:-1]
                env[k.strip()] = v
    except FileNotFoundError:
        pass
    if "WEB_PORT" in env and "PORT" not in env:      # older .env files
        env["PORT"] = env["WEB_PORT"]
    return env

if not os.path.exists(ENV_PATH):
    with open(ENV_PATH, "w", encoding="utf-8") as f:
        f.write(DEFAULT_ENV)
    print("Created .env with default settings.")

# ---- dependencies (falls back to a private .venv if system pip is locked, e.g. Ubuntu/macOS) ----
def ensure_deps():
    from importlib.util import find_spec
    if find_spec("flask") and find_spec("edge_tts"):       # no heavy imports at startup
        return
    pkgs = ["flask", "edge-tts"]
    print("Installing flask and edge-tts (first run only)...")
    if IS_TERMUX:   # pure-Python builds: no compiler, little RAM
        for k in ("AIOHTTP", "MULTIDICT", "YARL", "FROZENLIST", "PROPCACHE"):
            os.environ[k + "_NO_EXTENSIONS"] = "1"
        if subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--no-cache-dir"] + pkgs).returncode == 0:
            return
        sys.exit("Install failed. Run  bash termux-setup.sh  and try again.")
    if subprocess.run([sys.executable, "-m", "pip", "install", "-q"] + pkgs).returncode == 0:
        return
    print("System pip refused the install; creating a private .venv instead...")
    venv = os.path.join(HERE, ".venv")
    py = os.path.join(venv, "Scripts" if os.name == "nt" else "bin", "python" + (".exe" if os.name == "nt" else ""))
    if not os.path.exists(py):
        subprocess.check_call([sys.executable, "-m", "venv", venv])
    subprocess.check_call([py, "-m", "pip", "install", "-q"] + pkgs)
    sys.exit(subprocess.call([py, os.path.abspath(__file__)] + sys.argv[1:]))

ensure_deps()

import asyncio, atexit, logging, shutil, socket, threading, time, webbrowser
import urllib.request, urllib.error
from urllib.parse import urlparse
from flask import Flask, Response, jsonify, request, send_from_directory, stream_with_context

if not os.path.exists(os.path.join(HERE, "edumind.html")):
    sys.exit("Missing edumind.html. Keep start.py and edumind.html in the same folder.")

app = Flask(__name__)

# ---------------- website ----------------
@app.get("/")
@app.get("/edumind.html")
def index():
    resp = send_from_directory(HERE, "edumind.html")
    resp.headers["Cache-Control"] = "no-store"
    return resp

# ---------------- OmniRoute ----------------
SERVER_PORT = None

def points_to_self(base_url):
    """True if OMNIROUTE_BASE_URL is EduMind's own address (its /v1 share), which would loop forever."""
    u = urlparse(base_url)
    return u.hostname in ("localhost", "127.0.0.1", "::1") and u.port == SERVER_PORT
def omniroute_up(base_url):
    u = urlparse(base_url)
    try:
        urllib.request.urlopen(f"{u.scheme}://{u.netloc}", timeout=2)
        return True
    except urllib.error.HTTPError:
        return True                      # any HTTP answer means it is running
    except Exception:
        return False

@app.get("/api/status")
def status():
    base = load_env()["OMNIROUTE_BASE_URL"]
    loop = points_to_self(base)
    return jsonify(omniroute_url=base, omniroute_up=(not loop) and omniroute_up(base), loop=loop)

HOP = {"connection", "keep-alive", "transfer-encoding", "te", "trailer", "upgrade", "proxy-authorization",
       "proxy-authenticate", "content-length", "content-encoding", "host", "accept-encoding", "origin", "referer"}
METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]

def proxy(rest):
    """Forward the request to OmniRoute (streams the answer, keeps the caller's own API key)."""
    base = load_env()["OMNIROUTE_BASE_URL"]
    if points_to_self(base):
        return Response(f"OMNIROUTE_BASE_URL ({base}) is EduMind itself. The /v1 share forwards TO OmniRoute, so set it "
                        "to where OmniRoute really runs (default http://localhost:20128/v1).", status=508, mimetype="text/plain")
    url = base.rstrip("/") + "/" + rest.lstrip("/")
    if request.query_string:
        url += "?" + request.query_string.decode()
    headers = {k: v for k, v in request.headers if k.lower() not in HOP}
    headers["User-Agent"] = "EduMind/1.0"
    data = request.get_data() if request.method in ("POST", "PUT", "PATCH", "DELETE") else None
    try:
        try:
            r = urllib.request.urlopen(urllib.request.Request(url, data=data, headers=headers, method=request.method), timeout=300)
        except urllib.error.HTTPError as e:
            r = e                                    # still has a status, headers and body
    except Exception as e:
        return Response(f"OmniRoute is not running at {url}. Start it, or set OMNIROUTE_BASE_URL in .env to where it runs.", status=502, mimetype="text/plain")
    read = getattr(r, "read1", r.read)               # read1 passes streamed (SSE) chunks straight through
    def gen():
        try:
            while True:
                chunk = read(4096)
                if not chunk:
                    break
                yield chunk
        finally:
            r.close()
    out = [(k, v) for k, v in r.headers.items() if k.lower() not in HOP]
    return Response(stream_with_context(gen()), status=getattr(r, "status", None) or r.code, headers=out)

@app.post("/api/chat")                 # used by the EduMind page
def chat():
    return proxy("chat/completions")

@app.route("/v1/<path:rest>", methods=METHODS)     # OmniRoute's API, shared on this same port
def omniroute_api(rest):
    if load_env()["EXPOSE_OMNIROUTE_API"].lower() not in ("1", "true", "yes", "on"):
        return Response("OmniRoute API sharing is off (EXPOSE_OMNIROUTE_API in .env).", status=404, mimetype="text/plain")
    if request.method == "OPTIONS":
        return Response(status=204)
    return proxy(rest)

@app.after_request
def cors(resp):
    if request.path.startswith("/v1/"):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = ", ".join(METHODS)
    return resp

_omni_proc = None
def maybe_start_omniroute(env):
    global _omni_proc
    if env["OMNIROUTE_AUTOSTART"].lower() not in ("1", "true", "yes", "on"):
        return
    base = env["OMNIROUTE_BASE_URL"]
    if urlparse(base).hostname not in ("localhost", "127.0.0.1", "::1"):
        return
    if omniroute_up(base):
        print("OmniRoute       : already running")
        return
    exe = shutil.which("omniroute")
    if not exe:
        print("OmniRoute       : not found. Install it with `npm install -g omniroute` (or start it yourself).")
        return
    print("OmniRoute       : starting...")
    _omni_proc = subprocess.Popen([exe], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    atexit.register(lambda: _omni_proc and _omni_proc.terminate())
    for _ in range(30):
        if omniroute_up(base):
            print("OmniRoute       : running")
            return
        time.sleep(1)
    print("OmniRoute       : did not respond in 30 s; check it manually.")

# ---------------- Edge TTS ----------------
_voices = None

@app.get("/api/voices")
def voices():
    global _voices
    try:
        if _voices is None:
            import edge_tts                      # imported only when needed (faster start, less RAM)
            vs = asyncio.run(edge_tts.list_voices())
            _voices = [{"name": v["ShortName"], "locale": v["Locale"], "gender": v["Gender"]}
                       for v in vs if v["Locale"].startswith("en")]
        return jsonify(_voices)
    except Exception as e:
        return Response(str(e), status=500, mimetype="text/plain")

async def synth(text, voice, rate):
    import edge_tts
    buf = bytearray()
    async for ch in edge_tts.Communicate(text, voice, rate=rate).stream():
        if ch["type"] == "audio":
            buf += ch["data"]
    return bytes(buf)

@app.post("/api/tts")
def tts():
    d = request.get_json(force=True, silent=True) or {}
    text = (d.get("text") or "").strip()
    if not text:
        return Response("No text", status=400, mimetype="text/plain")
    try:
        audio = asyncio.run(synth(text, d.get("voice", "en-US-AriaNeural"), d.get("rate", "+0%")))
        return Response(audio, mimetype="audio/mpeg")
    except Exception as e:
        return Response(str(e), status=500, mimetype="text/plain")

# ---------------- run ----------------
def already_running(port):
    """True if an EduMind server is already answering on this port (e.g. an old Termux session)."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/status", timeout=1.5) as r:
            return b"omniroute_url" in r.read()
    except Exception:
        return False

def bind_server(host, wanted):
    """Really bind the socket, trying the next ports if one is taken (no check-then-bind gap)."""
    import io, contextlib
    from werkzeug.serving import make_server
    for port in range(wanted, wanted + 30):
        try:
            with contextlib.redirect_stderr(io.StringIO()):      # hide werkzeug's own "in use" message
                return make_server(host, port, app, threaded=True), port
        except (OSError, SystemExit):
            continue
    return None, None

def open_browser(url):
    def go():
        if IS_TERMUX:
            if shutil.which("termux-open-url"):
                r = subprocess.run(["termux-open-url", url], capture_output=True, text=True)
                out = (r.stdout or "") + (r.stderr or "")
                if r.returncode == 0 and "not started" not in out and "unable to resolve" not in out:
                    return
            print(f"\n>>> Open this address in your phone browser: {url}")
            print("    (To open it automatically, allow 'Display over other apps' for Termux in Android settings.)")
        else:
            webbrowser.open(url)
    threading.Timer(1.5, go).start()

if __name__ == "__main__":
    env = load_env()
    host = env["HOST"]
    try:
        wanted = int(env["PORT"])
    except ValueError:
        sys.exit("PORT in .env must be a number, for example PORT=8000")
    if already_running(wanted):
        url = f"http://localhost:{wanted}/edumind.html"
        print(f"EduMind is already running at {url}\nOpen that address. To restart it, press Ctrl+C in the window where it is running (or run: pkill -f start.py).")
        open_browser(url)
        time.sleep(2.5)
        sys.exit(0)
    srv, port = bind_server(host, wanted)
    if srv is None:
        sys.exit(f"No free port found between {wanted} and {wanted + 29}. Check what is running with:\n"
                 f"  Termux/Linux/Mac: lsof -i :{wanted}   or   ss -ltnp | grep {wanted}\n  Windows: netstat -ano | findstr :{wanted}")
    SERVER_PORT = port
    if port != wanted:
        print(f"Port {wanted} is busy, so EduMind is using {port} instead.")
    maybe_start_omniroute(env)
    url = f"http://localhost:{port}/edumind.html"
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    print(f"EduMind         : {url}")
    print(f"OmniRoute URL   : {env['OMNIROUTE_BASE_URL']}  (model: auto)")
    print("Edge TTS        : built in")
    if env["EXPOSE_OMNIROUTE_API"].lower() in ("1", "true", "yes", "on"):
        print(f"OmniRoute API   : shared on this port at /v1  (e.g. http://localhost:{port}/v1)")
    print("\nPress Ctrl+C to stop.")
    if IS_TERMUX and shutil.which("termux-wake-lock"):          # keep generating when the screen turns off
        subprocess.run(["termux-wake-lock"])
        atexit.register(lambda: subprocess.run(["termux-wake-unlock"]))
    open_browser(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        srv.server_close()
