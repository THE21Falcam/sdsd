"""EduMind: one Flask server for everything.

Usage:  python start.py        (Windows: py start.py)

One server on http://localhost:8000 that
  * serves the EduMind website
  * runs the Edge TTS voices   (/api/tts, /api/voices)
  * proxies OmniRoute requests (/api/chat) and can start OmniRoute for you
Settings live in the .env file. Press Ctrl+C to stop everything.
"""
import os, sys, subprocess
IS_TERMUX = "com.termux" in os.environ.get("PREFIX", "")
os.environ.setdefault("FLASK_SKIP_DOTENV", "1")

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
ENV_PATH = os.path.join(HERE, ".env")

DEFAULT_ENV = """# EduMind settings. Edit, save, then restart start.py.

# Your OmniRoute OpenAI-compatible endpoint (the model is always "auto").
# API keys are NOT stored here: every user enters their own key in the browser.
OMNIROUTE_BASE_URL=http://localhost:20128/v1

# Start OmniRoute automatically (runs the `omniroute` command if it is installed
# and nothing is listening yet). Ignored when the URL is not on this computer.
OMNIROUTE_AUTOSTART=true

# Where EduMind listens
HOST=127.0.0.1
PORT=8000
"""
if IS_TERMUX:   # a phone should not run OmniRoute (Node.js) next to this unless you ask for it
    DEFAULT_ENV = DEFAULT_ENV.replace("OMNIROUTE_AUTOSTART=true", "OMNIROUTE_AUTOSTART=false")
DEFAULTS = {"OMNIROUTE_BASE_URL": "http://localhost:20128/v1", "OMNIROUTE_AUTOSTART": "false" if IS_TERMUX else "true", "HOST": "127.0.0.1", "PORT": "8000"}

def load_env():
    env = dict(DEFAULTS)
    try:
        with open(ENV_PATH, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                v = v.strip()
                if " #" in v and v[:1] not in "'\"":
                    v = v.split(" #", 1)[0].strip()      # PORT=8000  # comment
                if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
                    v = v[1:-1]
                env[k.strip()] = v
    except FileNotFoundError:
        pass
    if "WEB_PORT" in env and "PORT" not in env:      # older .env files
        env["PORT"] = env["WEB_PORT"]
    return env

if not os.path.exists(ENV_PATH):
    with open(ENV_PATH, "w", encoding="utf-8") as f:
        f.write(DEFAULT_ENV)
    print("Created .env with default settings.")

# ---- dependencies (falls back to a private .venv if system pip is locked, e.g. Ubuntu/macOS) ----
def ensure_deps():
    from importlib.util import find_spec
    if find_spec("flask") and find_spec("edge_tts"):       # no heavy imports at startup
        return
    pkgs = ["flask", "edge-tts"]
    print("Installing flask and edge-tts (first run only)...")
    if IS_TERMUX:   # pure-Python builds: no compiler, little RAM
        for k in ("AIOHTTP", "MULTIDICT", "YARL", "FROZENLIST", "PROPCACHE"):
            os.environ[k + "_NO_EXTENSIONS"] = "1"
        if subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--no-cache-dir"] + pkgs).returncode == 0:
            return
        sys.exit("Install failed. Run  bash termux-setup.sh  and try again.")
    if subprocess.run([sys.executable, "-m", "pip", "install", "-q"] + pkgs).returncode == 0:
        return
    print("System pip refused the install; creating a private .venv instead...")
    venv = os.path.join(HERE, ".venv")
    py = os.path.join(venv, "Scripts" if os.name == "nt" else "bin", "python" + (".exe" if os.name == "nt" else ""))
    if not os.path.exists(py):
        subprocess.check_call([sys.executable, "-m", "venv", venv])
    subprocess.check_call([py, "-m", "pip", "install", "-q"] + pkgs)
    sys.exit(subprocess.call([py, os.path.abspath(__file__)] + sys.argv[1:]))

ensure_deps()

import asyncio, atexit, logging, shutil, socket, threading, time, webbrowser
import urllib.request, urllib.error
from urllib.parse import urlparse
from flask import Flask, Response, jsonify, request, send_from_directory

if not os.path.exists(os.path.join(HERE, "edumind.html")):
    sys.exit("Missing edumind.html. Keep start.py and edumind.html in the same folder.")

app = Flask(__name__)

# ---------------- website ----------------
@app.get("/")
@app.get("/edumind.html")
def index():
    resp = send_from_directory(HERE, "edumind.html")
    resp.headers["Cache-Control"] = "no-store"
    return resp

# ---------------- OmniRoute ----------------
def omniroute_up(base_url):
    u = urlparse(base_url)
    try:
        urllib.request.urlopen(f"{u.scheme}://{u.netloc}", timeout=2)
        return True
    except urllib.error.HTTPError:
        return True                      # any HTTP answer means it is running
    except Exception:
        return False

@app.get("/api/status")
def status():
    base = load_env()["OMNIROUTE_BASE_URL"]
    return jsonify(omniroute_url=base, omniroute_up=omniroute_up(base))

@app.post("/api/chat")
def chat():
    url = load_env()["OMNIROUTE_BASE_URL"].rstrip("/") + "/chat/completions"
    headers = {"Content-Type": "application/json", "User-Agent": "EduMind/1.0"}
    if request.headers.get("Authorization"):         # the user's own key, sent from their browser
        headers["Authorization"] = request.headers["Authorization"]
    req = urllib.request.Request(url, data=request.get_data(), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return Response(r.read(), status=r.status, content_type=r.headers.get("Content-Type", "application/json"))
    except urllib.error.HTTPError as e:
        return Response(e.read(), status=e.code, content_type=e.headers.get("Content-Type", "text/plain"))
    except Exception as e:
        return Response(f"Cannot reach OmniRoute at {url} ({e}). Is it running?", status=502, mimetype="text/plain")

_omni_proc = None
def maybe_start_omniroute(env):
    global _omni_proc
    if env["OMNIROUTE_AUTOSTART"].lower() not in ("1", "true", "yes", "on"):
        return
    base = env["OMNIROUTE_BASE_URL"]
    if urlparse(base).hostname not in ("localhost", "127.0.0.1", "::1"):
        return
    if omniroute_up(base):
        print("OmniRoute       : already running")
        return
    exe = shutil.which("omniroute")
    if not exe:
        print("OmniRoute       : not found. Install it with `npm install -g omniroute` (or start it yourself).")
        return
    print("OmniRoute       : starting...")
    _omni_proc = subprocess.Popen([exe], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    atexit.register(lambda: _omni_proc and _omni_proc.terminate())
    for _ in range(30):
        if omniroute_up(base):
            print("OmniRoute       : running")
            return
        time.sleep(1)
    print("OmniRoute       : did not respond in 30 s; check it manually.")

# ---------------- Edge TTS ----------------
_voices = None

@app.get("/api/voices")
def voices():
    global _voices
    try:
        if _voices is None:
            import edge_tts                      # imported only when needed (faster start, less RAM)
            vs = asyncio.run(edge_tts.list_voices())
            _voices = [{"name": v["ShortName"], "locale": v["Locale"], "gender": v["Gender"]}
                       for v in vs if v["Locale"].startswith("en")]
        return jsonify(_voices)
    except Exception as e:
        return Response(str(e), status=500, mimetype="text/plain")

async def synth(text, voice, rate):
    import edge_tts
    buf = bytearray()
    async for ch in edge_tts.Communicate(text, voice, rate=rate).stream():
        if ch["type"] == "audio":
            buf += ch["data"]
    return bytes(buf)

@app.post("/api/tts")
def tts():
    d = request.get_json(force=True, silent=True) or {}
    text = (d.get("text") or "").strip()
    if not text:
        return Response("No text", status=400, mimetype="text/plain")
    try:
        audio = asyncio.run(synth(text, d.get("voice", "en-US-AriaNeural"), d.get("rate", "+0%")))
        return Response(audio, mimetype="audio/mpeg")
    except Exception as e:
        return Response(str(e), status=500, mimetype="text/plain")

# ---------------- run ----------------
def port_is_free(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name != "nt":
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)   # same as Flask does
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()

def pick_port(host, wanted):
    for port in range(wanted, wanted + 30):
        if port_is_free(host, port):
            return port
    return None

if __name__ == "__main__":
    env = load_env()
    host = env["HOST"]
    try:
        wanted = int(env["PORT"])
    except ValueError:
        sys.exit("PORT in .env must be a number, for example PORT=8000")
    port = pick_port(host, wanted)
    if port is None:
        sys.exit(f"No free port found between {wanted} and {wanted + 29}. Check what is running with:\n"
                 f"  Windows : netstat -ano | findstr :{wanted}\n  Mac/Linux: lsof -i :{wanted}")
    if port != wanted:
        print(f"Port {wanted} is busy (another program or an old EduMind window is using it), so EduMind is using {port} instead.")
    maybe_start_omniroute(env)
    url = f"http://localhost:{port}/edumind.html"
    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    print(f"EduMind         : {url}")
    print(f"OmniRoute URL   : {env['OMNIROUTE_BASE_URL']}  (model: auto)")
    print("Edge TTS        : built in")
    print("\nPress Ctrl+C to stop.")
    if IS_TERMUX:
        if shutil.which("termux-wake-lock"):      # keep generating when the screen turns off
            subprocess.run(["termux-wake-lock"])
            atexit.register(lambda: subprocess.run(["termux-wake-unlock"]))
        if shutil.which("termux-open-url"):
            threading.Timer(1.5, lambda: subprocess.run(["termux-open-url", url])).start()
        else:
            print(f"Open this address in your phone browser: {url}")
    else:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host=host, port=port, threaded=True, debug=False)
