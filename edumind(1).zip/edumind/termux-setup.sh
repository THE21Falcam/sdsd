#!/data/data/com.termux/files/usr/bin/bash
# EduMind setup for Termux (low-RAM phones). Run once:  bash termux-setup.sh
set -e
echo "== EduMind: Termux setup =="
pkg update -y
pkg install -y python

# Pure-Python builds: no compiler needed, so low RAM/swap is not a problem.
export AIOHTTP_NO_EXTENSIONS=1 MULTIDICT_NO_EXTENSIONS=1 YARL_NO_EXTENSIONS=1 \
       FROZENLIST_NO_EXTENSIONS=1 PROPCACHE_NO_EXTENSIONS=1
# (do not run "pip install --upgrade pip": Termux forbids it)
pip install --no-cache-dir flask edge-tts

if [ -f .env ]; then
  sed -i 's/^OMNIROUTE_AUTOSTART=.*/OMNIROUTE_AUTOSTART=false/' .env
else
  cat > .env <<'ENV'
# EduMind settings. Edit, save, then restart start.py.
# Point this at your OmniRoute (the model is always "auto").
OMNIROUTE_BASE_URL=http://localhost:20128/v1
OMNIROUTE_AUTOSTART=false
HOST=127.0.0.1
PORT=8000
ENV
fi
echo
echo "Done. Start EduMind with:  python start.py"
